# Beacon based code generator

## System Architecture

![](image/tongyi-mermaid-2025-12-18-225637_ZCVSqj3zlY.png)

This section presents the overall architecture of our **Beacon-augmented multi-agent code generation system** and explains how **multi-function reasoning**, **structured memory**, and **retrieval**are integrated into an end-to-end pipeline that can be evaluated in pragmatic benchmarks such as **CoderEval**.

### Overview

Our system is designed around a single principle: **Beacon Logic should not be treated as plain prompt context**, but as a **structured intermediate representation (IR)** that is (i)*interpretable*, (ii) *persistable*, and (iii)*retrievable* across tasks. To operationalize this, we introduce a modular architecture that consists of: (1) task ingestion, (2) Beacon reasoning, (3) multi-level memory management, (4) collaborative agents for generation and verification, and (5) execution-based evaluation with feedback.

At a high level, each CoderEval task is converted into a normalized task object, analyzed by a Beacon Reader agent that produces a graph-structured Beacon IR, then jointly processed by a**Code Generator**and a**Verifier** agent under Beacon constraints. The final code is injected into the benchmark’s runtime environment (Docker) and tested against the original project tests. Both structural and execution outcomes are written back to memory to support retrieval and continual refinement.

### Task Ingestion and Context Assembly

Given an evaluation task (t) (e.g., a function-level generation instance in CoderEval), the ingestion module constructs a**Task Object**:
\[
\mathcal{T} = \langle id, lang, sig, doc, ctx, lvl \rangle,
]
where (sig) is the function signature, (doc) is the natural language specification (docstring/comment), (ctx) is the contextual dependency bundle (imports, referenced symbols, helper functions, constants, and relevant file/project context), and (lvl) denotes the runnable-level category (e.g., file-runnable or project-runnable). This step produces a consistent interface for downstream reasoning, memory, and generation modules.

### Beacon Reasoning Layer

The Beacon Reasoning Layer converts (\mathcal{T}) into a compact semantic scaffold using**multi-function Beacon Logic**. It is implemented by a specialized**Beacon Reader Agent**, which performs two complementary passes:

**(1) Local Reasoning.For each function (f), local reasoning constructs a backward semantic closure from**observable outputs (e.g., return, print, log) by expanding data/control dependencies. Validation-like branches are optionally filtered to reduce non-essential logic. Conceptually, this corresponds to applying the local rules (e.g., output rooting and dependency expansion) followed by heuristic filtering and normalization.

**(2) Global Reasoning.Global reasoning propagates beacons across the call graph to capture multi-function semantics. When a call site is deemed semantically relevant, the callee’s beacon set is inlined into the caller’s global beacon set, and return-flow / global-state interactions are conservatively tracked. This yields a**program-aware semantic core rather than an isolated function summary.

The output of reasoning is the**Beacon IR**, a structured representation:
\[
\mathcal{B} = \langle N, E, S, F, P, \Pi \rangle,
]
where (N) are beacon nodes (semantic core statements/operations), (E) includes typed edges (dataflow edges, control edges, call edges), (S) are referenced symbols (globals, imports, attributes), (F) denotes forbidden patterns (e.g., filtered validation paths), (P) is a canonical skeleton (pseudo-code or constrained outline), and (\Pi) is provenance metadata that records which reasoning rule(s) introduced each node. This provenance makes Beacon IR explainable and enables fine-grained diagnostics during verification.

### Multi-Level Memory Management

To support reuse and retrieval beyond single-task prompts, we introduce a dedicated**Memory Manager** with three layers:

**Working Memory** (\mathcal{M}\_w): a short-lived store scoped to the current task. It contains the Beacon IR, intermediate code drafts, verifier reports, and execution traces. Working memory is cleared after completing the task.

**Project Memory** (\mathcal{M}\_p): a persistent store keyed by project/module/file identifiers. It accumulates stable knowledge such as frequently used helper semantics, project-specific conventions, global symbol roles, and recurring beacon subgraphs. This layer is crucial for pragmatic benchmarks where multiple tasks originate from the same project context.

**Experience Memory**(\mathcal{M}\_e): a cross-task episodic store intended for retrieval-augmented refinement. Each entry is a structured “experience unit”:
\[
x = \langle \sigma, lvl, err, viol, fix \rangle,
]
where (\sigma) is a dependency signature (context + call/dataflow fingerprint), (lvl) is runnable-level, (err) is an execution error category (e.g., NameError, type mismatch), (viol) is a Beacon-level violation type (missing beacon, hallucinated symbol, forbidden path), and (fix) is a patch strategy (instruction template or diff-like transformation). This design makes memory directly actionable for both generation and verification.

### Collaborative Agent Layer

Our architecture employs three agents that communicate through Beacon IR and memory rather than unconstrained natural language:

**Beacon Reader Agent.**Produces (\mathcal{B}) and writes it into (\mathcal{M}*w), while updating (\mathcal{M}* p) when stable project knowledge is detected.

**Code Generator Agent.**Generates implementation code conditioned on (\mathcal{B}). Instead of treating beacons as optional hints, the generator is required to satisfy structural constraints: required call sequence, key intermediate variables, core dataflow, and restricted patterns. The generator may also query (\mathcal{M}*p) for project conventions and (\mathcal{M}* e) for analogous solutions or patch templates.

**Verifier Agent.** Performs Beacon-guided structural verification before any execution. It checks: (i) beacon coverage (required nodes/edges present), (ii) dependency alignment (dataflow/call edges respected), (iii) symbol grounding (no hallucinated references), and (iv) forbidden-pattern compliance (no reintroduced validation paths). If violations are detected, the verifier produces a structured feedback report and revision directives, which loop back to the generator. This yields a constrained refinement cycle:
\[
\text{Generate} \rightarrow \text{Verify} \rightarrow \text{Revise},
]
which reduces the probability of producing code that fails due to structural misalignment.

### Execution, Evaluation, and Feedback

After the verifier accepts a candidate, the system injects the generated code into the benchmark runtime (e.g., CoderEval Docker environment) by replacing the target function/method in the original project. The benchmark then compiles/runs the project tests and reports pass/fail outcomes and traces. We record both**execution-level outcomes**(test failures, exceptions, compilation errors) and**structure-level outcomes** (beacon violations detected by the verifier).

Finally, these outcomes are used to update memory: execution traces and recurring patterns update (\mathcal{M}*p), while failure-to-fix trajectories create new experience units in (\mathcal{M}* e). This closes the loop between pragmatic evaluation and system improvement, enabling retrieval-augmented refinement across tasks without requiring model fine-tuning.

### Discussion

By elevating Beacon Logic to a structured and persistent IR and placing it at the center of a multi-agent collaboration loop, our architecture bridges semantic reasoning, generation, and verification in a way that is directly compatible with pragmatic, project-level benchmarks. The design explicitly supports ablation studies (e.g., removing global reasoning, disabling memory retrieval, or omitting the verifier) to quantify the contributions of each component to pass rates and failure modes in realistic environments.
